---
name: sudev-tasarim
description: "SÜDEV (Selçuk Üniversitesi Yazılım Geliştirme Topluluğu) marka ve tasarım dili — web sitesinin ziyaretçi yüzüyle birebir aynı dil, sosyal medya içerikleri için. Kullan: SÜDEV için Instagram gönderisi, carousel, story, LinkedIn/X görseli, etkinlik afişi, duyuru görseli, kapak, OG görseli, sunum kapağı ya da herhangi bir marka görseli üretilirken; 'SÜDEV postu', 'etkinlik görseli', 'duyuru', 'story', 'carousel', 'afiş', 'codex ile görsel üret' dendiğinde. Claude metni ve yerleşimi kurar, Codex (image_generation) yalnız görsel malzemeyi üretir, son görsel HTML'den PNG'ye basılır."
---

# SÜDEV Tasarım Dili — Sosyal Medya

Sosyal medya **sitenin dilini** konuşur. Kaynak gerçek: site reposundaki `toplulukweb/app/globals.css` (`.site` bloğu) ve `app/opengraph-image.tsx`. Bu skill'deki değerler oradan alındı. Repo erişimin varsa ve site değişmişse önce oraya bak; yoksa bu dosyadaki değerler geçerlidir.

Dilin tek cümlesi: **Hack Club'ın bileşenleri, MLH'nin dili, SÜDEV'in logodan gelen renkleri.** Kalın monospace başlık, 2px mürekkep kenarlı kutular, blok (ofsetli, bulanıksız) gölge, ızgaralı çizim kâğıdı zemin, eğik polaroid fotoğraflar, turuncu vurgu kelime.

Topluluk mottosu (uydurma slogan yerine her zaman bu): **Merakla başla, sorumlulukla yüksel, bilgiyle parla.**

---

## 1. İş bölümü — kim ne yapar

| Adım | Kim | Çıktı |
|---|---|---|
| Brief, metin, hiyerarşi, format seçimi | **Claude** | Başlık, alt metin, meta satırı, caption, hashtag |
| Görsel malzeme: foto-gerçekçi sahne, illüstrasyon, sticker, doku | **Codex** (`image_generation`) | Metinsiz PNG |
| Kompozisyon: zemin, kart, tipografi, logo, malzemenin yerleşimi | **Claude** (HTML şablon) | `post.html` |
| Baskı | `scripts/render.mjs` (Playwright) | Tam piksel PNG |
| Kontrol | **Claude** (görseli Read ile açıp bakar) | §8 listesi |

**Kural: Görsel modeline asla metin yazdırılmaz.** Türkçe diyakritikler (ı İ ş ğ ü ö ç) bozulur, font dilin dışına çıkar, logo uydurulur. Yazı, logo, tarih, sayı her zaman HTML katmanında gerçek fontla basılır. Codex'ten gelen görsel **metinsiz** olmalı; içinde harf varsa reddet ve yeniden üret.

---

## 2. Renk (logodan örneklendi)

```
--paper      #F7F7F5   sayfa zemini (krem DEĞİL, sıcak kırık beyaz)
--grid-bg    #F1F1EF   ızgaralı "blueprint" zemin
--card       #FFFFFF   kart
--ink        #16181A   metin, 2px kenar, blok gölge
--ink-2      #494D52   gövde metni
--ink-3      #6A6F76   meta, caption
--sun        #E97E2D   logo turuncusu: rozet zemini, ana düğme zemini (üstünde MÜREKKEP metin, beyaz değil)
--sun-deep   #8F3D0C   blush üstünde turuncu metin
--flame      #BF5316   küçük turuncu metin/vurgu (4.6:1)
--sea        #046096   logo mavisi: ikinci renk, etiket zemini (üstünde beyaz metin)
--night      #0B2D47   koyu mavi bant
--blush      #FDF0E6   sıcak bant zemini
--blush-2    #F9DCC6   blush halkası
--soot       #17171D   koyu kart/bant zemini (üstünde beyaz metin, turuncu ikon)
Vurgu kelime gradyanı: linear-gradient(90deg, #D2651A, #B04A12)  (yalnız metin, background-clip:text)
```

- Logo iki renklidir ve bu bir fikirdir: **SÜ turuncu (üniversite), DEV mavi (zanaat).** Tek renge indirilebilir (mürekkep ya da beyaz); başka renge boyanamaz, gradyan/gölge/3B eklenemez.
- Baskın yüzey her zaman açık (paper / grid / blush). Koyu `soot`/`night` bant bir gönderide en fazla bir blok.
- Neon, cyan, mor, glow, glassmorphism, çok renkli gradyan **yok**.

## 3. Tipografi

| Rol | Font | Ağırlık | Tracking | Not |
|---|---|---|---|---|
| Başlık, büyük sayı | **JetBrains Mono** | 800 | -0.04em | leading 1.02–1.1 |
| Alt başlık, düğme, etiket | JetBrains Mono | 700 | 0 / etiketlerde 0.1em UPPERCASE | |
| Gövde (uzun metin, carousel içi) | JetBrains Mono 400–500, uzun paragraflarda **IBM Plex Sans** 400 | | 0 | satır 1.6 |
| Meta (tarih, saat, yer, ID) | JetBrains Mono / IBM Plex Mono | 500 | 0.02em | `ink-3` |

- Fontlar Google Fonts'tan `latin-ext` ile yüklenir (Türkçe glifler o alt kümede).
- Başlıkta **tek** vurgu kelime/ifade turuncu gradyanla (`.ink-sun`). Birden fazla renkli kelime yok, harf harf renk yok.
- Heceleme yok; satır yalnız boşluktan kırılır. Başlığı elle 2–3 satıra böl.
- Tarih biçimi Türkçe: `12 Ekim 2026 · 18:30`, dönem `2026–27`.

## 4. Bileşenler (siteden birebir)

- **Kutu / kart**: beyaz, `2px solid #16181A`, radius 10px. Öne çıkan kartta blok gölge `6px 6px 0 #16181A`.
- **Düğme / CTA** (`.pill`): yükseklik ~58px (1080 tuvalde), radius 4px, `2px` mürekkep kenar, blok gölge `3–5px` ofset, metin 700. Ana CTA `--sun` zemin + mürekkep metin; ikincil beyaz zemin; koyu varyant `--soot` zemin + beyaz metin. Yanına `→` ok konmaz.
- **Rozet / etiket**: `radius 4px`, `2px` mürekkep kenar, 700 UPPERCASE küçük metin — ya da `--sea` zemin + beyaz metin. Yuvarlak "hap" rozet: `--blush` zemin + `--sun-deep` metin, radius 999px.
- **Blueprint zemin**: `#F1F1EF` + 1px çizgili ızgara `rgba(22,24,26,.06–.07)`, hücre 22–28px (1080 tuvalde 36–44px).
- **Polaroid**: beyaz çerçeve (6/6/22 oranı, büyüt), radius 3px, yumuşak gölge `0 2px 4px rgba(0,0,0,.12), 0 12px 28px -10px rgba(0,0,0,.35)`, **±3–6° eğik**. Bu dilde yumuşak gölgenin serbest olduğu tek yer.
- **Canlı nokta**: `--sun` dolu daire + etrafında halka — "şimdi / başvuru açık / canlı" demek için.
- **Kayıt satırı**: solda başlık, sağda mono meta, aralarda 1px `#E4E6E8` çizgi — program akışı, konuşmacı listesi, sonuç tablosu için.
- **Numaralı adım**: `--blush` daire içinde numara, `--sun-deep` renkli — yalnız gerçekten sıralı içerikte (başvuru adımları, merak → sorumluluk → bilgi).

## 5. Formatlar

| Kanal | Boyut | Güvenli alan |
|---|---|---|
| Instagram gönderi / carousel | **1080×1350** (4:5) | kenarlardan 72px; profil ızgarası ortadaki 1080×1080'i kırpar — başlık orada kalsın |
| Instagram kare | 1080×1080 | 72px |
| Story / Reels kapak | 1080×1920 | üstten 250px, alttan 340px boş (arayüz) |
| LinkedIn gönderi | 1200×1500 veya 1200×1200 | 72px |
| LinkedIn/X link görseli, OG | 1200×630 (site OG şablonu referans) | 56px |
| X gönderi | 1600×900 | 80px |

Carousel: ilk kart kapak (başlık + motto dili + logo), son kart CTA (başvuru linki / takip). Kart numarası sağ üstte mono `02/07` — carousel gerçekten sıralı olduğu için meşru. Tüm kartlarda aynı zemin ve ızgara hizası; kartlar yan yana dizilince tek bant gibi aksın.

## 6. Kompozisyon kalıpları

1. **Etkinlik duyurusu**: blueprint zemin → üstte hap rozet (`ATÖLYE`, `HACKATHON`, `SÖYLEŞİ`) → dev başlık (bir kelime turuncu) → kayıt satırları (tarih / saat / yer, mono) → alt satırda `.pill` CTA + logo. Codex görseli varsa sağ üst/alt köşede eğik polaroid.
2. **Etkinlik sonrası (kanıt postu)**: 2–4 gerçek fotoğraf polaroid kolaj, eğik ve üst üste; altında beyaz kart: ne yapıldı + **sayılar** (katılımcı, proje, saat) büyük mono 800.
3. **Proje/başarı**: soot bant içinde beyaz başlık + turuncu ikon, altında 3'lü istatistik kutusu (2px beyaz/15 kenar). Teknofest finalisti gibi ölçülebilir sonuç öne.
4. **Başvuru / katıl**: blush bant, ortada kart, 3 numaralı adım (merak → sorumluluk → bilgi), ana turuncu CTA.
5. **Alıntı / konuşmacı**: kare portre (radius 0, 2px kenar), isim 800, ünvan `--flame` 700, alıntı Plex Sans.

İçerik ilkesi siteyle aynı: **kanıt yoğunluğu**. Tarih, isim, sayı, çıktı. Boş hype ("Geleceği kodluyoruz 🚀") yazılmaz.

## 7. Codex ile görsel üretimi

> Codex CLI kurulu değilse bu adımı ortamdaki başka bir görsel üretim aracıyla (aynı prompt şablonu ve kurallarla) yap, hiçbiri yoksa görselsiz, yalnız tipografi + blueprint zeminle tasarla ya da kullanıcıdan gerçek fotoğraf iste.

Codex yalnız **malzeme** üretir. Çağrı (proje klasöründe, çıktı yolunu açıkça ver):

```bash
cd "<çalışma klasörü>" && codex exec --skip-git-repo-check --enable image_generation \
  -o /tmp/codex-son.txt \
  "image_generation aracıyla BİR görsel üret ve PNG olarak ./assets/<ad>.png yoluna kaydet. Kaydettiğin yolu son mesajda yaz.
PROMPT: <aşağıdaki şablon>"
```

Kaydetmezse `~/.codex/generated_images/` altında en yeni dosyaya bak (`ls -t ... | head`). Referans foto (gerçek etkinlik fotoğrafı, logo) varsa `-i foto.jpg` ile ekle ve "bu fotoğrafı stilize et / arka planını temizle" de.

**Prompt şablonu** (İngilizce yaz, model daha tutarlı):

```
<konu: ör. "university students collaborating around laptops at a hackathon table">.
Style: <aşağıdakilerden biri>.
Palette strictly: warm off-white #F7F7F5, ink #16181A, orange #E97E2D, deep blue #046096, soft peach #FDF0E6. No other hues.
Absolutely NO text, letters, numbers, logos, watermarks or UI screenshots with readable text.
No neon, no glow, no purple/cyan, no glossy 3D, no gradients backgrounds.
Composition: subject centered with generous empty margins, <en-boy oranı> aspect.
```

Stil seçenekleri (gönderi başına bir tane):
- **Belgesel foto**: `candid documentary photo, natural window light, slightly warm, true-to-life, shallow depth of field, Turkish university setting` — polaroid içine koymak için.
- **Sticker/ikon**: `flat die-cut sticker, thick 6px black outline, solid fills from the palette, white sticker border, hard offset black drop shadow, isolated on plain white background` — kolajda, köşelerde.
- **Çizgi illüstrasyon**: `bold hand-inked line illustration, thick uniform black strokes, flat orange and blue spot fills, blueprint technical-drawing feel, plain off-white background`.
- **Nesne/obje**: `studio photo of <nesne> on plain #F1F1EF background, hard light, crisp black shadow offset down-right`.

Üretilen görseli **Read ile aç ve bak**: metin/harf, fazladan renk, bozuk el/yüz, uydurma logo varsa yeniden üret. Gerçek kişi portresi Codex'e üretilmez — gerçek fotoğraf kullanılır (rıza şartı siteyle aynı).

## 8. Kompozisyon ve baskı

1. `templates/post.html` dosyasını çalışma klasörüne kopyala (`sosyal/<tarih>-<slug>/post.html`), tuval boyutunu `--w/--h` ile ayarla, metni ve görselleri yerleştir. Logo: `assets/sudev-mark.svg` (amblem), `sudev-wordmark.svg` (yazı), `sudev-logo.svg` (ikisi birlikte) — dosyaları yanına kopyala.
2. Bas:
   ```bash
   node <bu skill'in klasörü>/scripts/render.mjs post.html post.png 1080 1350
   ```
   Playwright gerekir (`npm i -D playwright && npx playwright install chromium`). Node/Playwright çalıştırılamayan bir ortamdaysan (ör. claude.ai sohbet) son çıktı olarak hazır HTML'i ver; kullanıcı tarayıcıda açıp tuval boyutunda ekran görüntüsü alır.
   Carousel için her kart ayrı `kart-01.html` … veya tek HTML'de `?k=1` parametresi; her kartı ayrı bas.
3. PNG'yi Read ile aç ve kontrol et:
   - [ ] Türkçe karakterler doğru (ı İ ş ğ), taşma/kesilme yok
   - [ ] Tek turuncu vurgu, logo iki renkli ve bozulmamış
   - [ ] Kutular 2px mürekkep kenar, gölgeler blok (bulanıksız) — polaroid hariç
   - [ ] Görselde model üretimi harf yok
   - [ ] Güvenli alan (özellikle story ve IG ızgara kırpması)
   - [ ] Kontrast: küçük metin ≥ 4.5:1 (beyaz metin turuncu zemine KONMAZ; `--sun` üstünde mürekkep)
   - [ ] Tarih/saat/yer/link doğru — uydurma bilgi yok, bilinmeyeni kullanıcıya sor

## 9. Caption ve ton

- Türkçe, "biz" dili, samimi ama ciddi; öğrenci topluluğu, kurumsal değil. Emoji en fazla 1–2, süs değil işaret olarak.
- İlk satır ne olduğunu söyler: `DevFest Konya'da 3 atölye veriyoruz.` Sonra tarih/yer/link, sonra tek cümle neden.
- Sayı ve isim kullan. "Muhteşem", "efsane", "kaçırma!!!" yok.
- Link: `sudev.net.tr` (başvuru/etkinlik sayfası). Hashtag sona, 3–6 adet: `#SÜDEV #SelçukÜniversitesi #Konya` + konuya özel.

## 10. Kullanıcı geri bildirimleri (uygulanır)

- **Kısa ve öz.** Görselde başlık + tek CTA + logolar yeter. Paragraf, bilgi kartı ve motto satırını dolgu için ekleme. Caption 1-2 satır ve 3 hashtag.
- **Gerçek logo, uydurma etiket değil.** Etkinlik veya kurum adı (Teknofest, takım adı) varsa resmî logosu kullanılır; yerine hap etiket (`TEKNOFEST 2026`) koymak "AI slop" sayılır. Resmî logo PDF veya AI dosyası olarak geliyorsa `pdftocairo -svg` ile SVG'ye çevrilir ve viewBox içeriğe kırpılır. Takım logosu beyaz `card lift` kutusunun içine konur.
- **Story ≠ uzatılmış post.** 9:16'da kompozisyon yeniden kurulur. Başlık post'takinden büyük olmalı (1080 genişlikte ~190px) ve odak bandında durmalı (yüksekliğin %30–50'si). Takım logosu ikincil kalır (~220px). Orta bölge sticker ya da fotoğrafla doldurulur. Alt bant y ≈ 1440'ta biter, altındaki 340px boş kalır. Reels kapağı için ayrı versiyon yapılır: altta %35 caption alanı, sağda ~120px ikon sütunu.
- Bilinen kaynaklar: TEKNOFEST resmî logo paketi teknofest.org/en/corporate/identity sayfasında (TR zip: `TR_TEKNOFEST_*.zip`, renkli `t3-logo-TR.pdf`). UniChain SVG takımın kendi logo klasöründedir; yoksa kullanıcıdan iste.

## 11. Yasaklar (sitenin reddettiği şeyler)

Neon/cyan/mor, glow, glassmorphism, parçacık ağı, "hacker terminali" kostümü, yeşil matrix kodu, harf harf gradyan, birden fazla renkli kelime, italik vurgu (motto altındaki `--sea` italik alt satır hariç), ALL-CAPS uzun başlık, stok fotoğraf hissi veren gülümseyen model, görsel üstüne binen koyu overlay + ortalanmış metin, uydurma logo, AI'nin yazdığı metin, `vision.md` gibi sahte dosya adı etiketleri, `01/02/03` sahte numaralandırma.
