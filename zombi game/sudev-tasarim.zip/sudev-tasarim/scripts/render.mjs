// HTML şablonunu tam piksel PNG'ye basar.
// Kullanım: node render.mjs <girdi.html> <çıktı.png> [genişlik=1080] [yükseklik=1350] [ölçek=1]
import { createRequire } from "node:module";
import { resolve } from "node:path";
import { pathToFileURL } from "node:url";
import { homedir } from "node:os";

const [input, output, w = "1080", h = "1350", scale = "1"] = process.argv.slice(2);
if (!input || !output) {
  console.error("Kullanım: node render.mjs <girdi.html> <çıktı.png> [genişlik] [yükseklik] [ölçek]");
  process.exit(1);
}

// playwright: önce normal çözümleme, yoksa SÜDEV site reposundaki kurulum.
async function loadPlaywright() {
  try {
    return await import("playwright");
  } catch {
    const site = process.env.SUDEV_SITE ?? resolve(homedir(), "Desktop/Südev site/toplulukweb");
    try {
      return createRequire(resolve(site, "package.json"))("playwright");
    } catch {
      console.error("Playwright bulunamadı. Kur: npm i -D playwright && npx playwright install chromium");
      process.exit(1);
    }
  }
}

const { chromium } = await loadPlaywright();
const browser = await chromium.launch();
const page = await browser.newPage({
  viewport: { width: Number(w), height: Number(h) },
  deviceScaleFactor: Number(scale),
});
await page.goto(pathToFileURL(resolve(input)).href, { waitUntil: "networkidle" });
await page.evaluate(() => document.fonts.ready);
await page.screenshot({ path: resolve(output), clip: { x: 0, y: 0, width: Number(w), height: Number(h) } });
await browser.close();
console.log(`basıldı: ${resolve(output)} (${w}×${h} @${scale}x)`);
